# advantitious_bush/__init__.py

from .advantitious_bush import AdvantitiousBush

__all__ = [
    'AdvantitiousBush',
]
